#!/sbin/sh

run_program("/sbin/busybox", "mount", "/system");


